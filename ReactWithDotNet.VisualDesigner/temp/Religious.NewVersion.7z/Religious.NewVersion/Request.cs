﻿using BOA.Common.Types;
using BOA.InternetBanking.Common;

namespace BOA.InternetBanking.Payments.API.Types.Religious;

public sealed class Request : BaseClientRequest
{
    /// <summary>
    ///     Gets the data contract.
    /// </summary>
    public required DataContract DataContract { get; init; }

    /// <summary>
    ///     Gets the state of the form.
    /// </summary>
    public required State State { get; set; }

    /// <summary>
    ///     Gets the items source.
    /// </summary>
    public required ItemsSource ItemsSource { get; set; }


    #region Response
    public bool? Success { get; set; }
    
    public Result? Result { get; set; }
    #endregion
}