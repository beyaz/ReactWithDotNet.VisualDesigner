﻿using BOA.Common.Types;
using BOA.InternetBanking.Common;
using BOA.InternetBanking.Common.Base;
using BOA.Types.InternetBanking.Payments;
using BOA.Types.Kernel.PaymentSystems.Religious;
using Microsoft.AspNetCore.Mvc;
using Request = BOA.InternetBanking.Payments.API.Types.Religious.Request;

namespace BOA.InternetBanking.Payments.API.Controllers;

[Route("[controller]/[action]")]
[ApiController]
public class ReligiousController : CommonControllerBase
{
    [HttpPost]
    public Request HandleNextAction(Request request)
    {
        request.State = request.State with
        {
            NextStepIsAvailable = request.DataContract.CanGoNext == "true"
        };

        return request;
    }

    [HttpPost]
    public async Task<Request> LoadData(Request request)
    {
        List<RegistrationDefinitionContract> registrationList;
        {
            var response = await LoadRegistrationDefinition();
            if (!response.Success)
            {
                return GetGenericErrorResponse(response.Results);
            }

            registrationList = response.Value;
        }

        foreach (var item in registrationList)
        {
            item.RegistrationName = item.RegistrationName + " (" + item.ProcessStatusName + ")";
        }
        
        return new Request
        {
            DataContract = new(),
            
            ItemsSource = new()
            {
                RegistrationList = registrationList,
                
                RecordTypes = new List<TextValue>
                {
                    new TextValue { Text = "AA", Value  = "abc3" },
                    new TextValue { Text = "AA2", Value = "abc2" }
                },
                PaymentTypes = new List<TextValue>
                {
                    new TextValue { Text = "qw", Value  = "val1" },
                    new TextValue { Text = "qw2", Value = "val2" }
                }
            },
            State = new()
        };
    }

    static Request GetGenericErrorResponse(IReadOnlyList<Result> results)
    {
        return new Request
        {
            Result       = results[0],
            Success      = false,
            DataContract = new(),
            State        = new(),
            ItemsSource  = new() { RecordTypes = [], PaymentTypes = [] }
        };
    }

    // todo add base
    Task<GenericResponse<TResponse>> Execute<TResponse, TRequest>(TRequest request) where TRequest : RequestBase, new()
    {
        return Executer.Execute<TRequest, GenericResponse<TResponse>>(request, HttpContext);
    }

    Task<GenericResponse<List<RegistrationDefinitionContract>>> LoadRegistrationDefinition()
    {
        var request = new ReligiousInfoRequest
        {
            RegistrationDefinitionContract = new RegistrationDefinitionContract
            {
                ChannelId = (byte)ChannelContract.Internet
            },
            MethodName = "SelectForPayment"
        };
        return Execute<List<RegistrationDefinitionContract>, ReligiousInfoRequest>(request);
    }
}