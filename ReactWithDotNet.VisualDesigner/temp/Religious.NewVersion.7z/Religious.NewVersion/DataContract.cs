﻿namespace BOA.InternetBanking.Payments.API.Types.Religious;

public sealed record DataContract
{
    public string? CanGoNext { get; init; }
    
    public string? SelectedRecordType { get; init; }
    
    public string? SelectedPaymentType { get; init; }
    
    public string? TCKN { get; init; }
    
    public string? SecurityCode { get; init; }
    
    public string? PhoneNumber { get; init; }
    
    public string? TourCode { get; init; }
    
    public DateTime? BirthDate { get; init; }
}