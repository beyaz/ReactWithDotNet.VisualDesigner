﻿namespace BOA.InternetBanking.Payments.API.Types.Religious;

public sealed record State
{
    public bool? IsTCKNDisabled { get; init; }
    
    public bool? NextStepIsAvailable { get; init; }
    
    public int? Step { get; init; }
}