﻿using BOA.InternetBanking.Common;
using BOA.Types.Kernel.PaymentSystems.Religious;

namespace BOA.InternetBanking.Payments.API.Types.Religious;

public sealed record ItemsSource
{
    public required IReadOnlyList<TextValue> RecordTypes { get; init; }
    
    public required IReadOnlyList<TextValue> PaymentTypes { get; init; }

    public IReadOnlyList<RegistrationDefinitionContract> RegistrationList { get; init; } = [];
}