﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BOA.Web.Base;
using BOA.Web.InternetBanking.Extensions.Models;

namespace BOA.Web.InternetBanking.Religious.Models
{
    /// <summary>
    /// ConfirmModel Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public class ConfirmModel : BWizardModel
    {
        public SecureConfirmModel SecureConfirm
        {
            get;
            set;
        }
    }
}
