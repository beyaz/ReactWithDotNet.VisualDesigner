﻿using BOA.Types.Kernel.General;
using BOA.Types.Kernel.PaymentSystems.Religious;
using BOA.Web.Base;
using BOA.Web.Base.Attributes;
using BOA.Web.Base.Types;
using BOA.Web.Base.Utils;
using BOA.Web.InternetBanking.Extensions.Models;
using System.Collections.Generic;

namespace BOA.Web.InternetBanking.Religious.Models
{
    /// <summary>
    /// IndexModel Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public class IndexModel : BWizardModel
    {
        public string TRIdentificationNo
        {
            get;
            set;
        }

        public int? RegistrationDefinitionId
        {
            get;
            set;
        }
        public int? RegistrationDefinitionCode
        {
            get;
            set;
        }
        public RegistrationDefinitionContract SelectedRegistrationDefinitionContract
        {
            get;
            set;
        }

        public string TourCode
        {
            get;
            set;
        }

        public string CompanyCode
        {
            get;
            set;
        }

        public short? OrgSaveType
        {
            get;
            set;
        }

        public string SecurityCode
        {
            get;
            set;
        }
        public List<ReligiousAgreementContract> AggrementList { get; set; }
        public SecureConfirmAgreementModel SecureConfirmForAgreementModel { get; set; }
    }
}
