﻿using BOA.Types.InternetBanking;
using BOA.Web.Base;
using BOA.Web.Base.Attributes;
using BOA.Web.Base.Types;

namespace BOA.Web.InternetBanking.Religious.Models
{
    /// <summary>
    /// Index2Model Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public class Index2Model : BWizardModel
    {
        public string PhoneNumber
        {
            get;
            set;
        }

        public int SelectedInstallmentNumber
        {
            get;
            set;
        }

        public Money Amount
        {
            get;
            set;
        }

        public bool SelectedRegistrationIsContribution
        {
            get;
            set;
        }
        /// <summary>
        /// Index2Model Constructor
        /// TODO: More detail
        /// </summary>
        public Index2Model()
        {
            Amount = new Money()
            {
                FECCode = FecConstantsText.USD
            };
        }
    }
}
