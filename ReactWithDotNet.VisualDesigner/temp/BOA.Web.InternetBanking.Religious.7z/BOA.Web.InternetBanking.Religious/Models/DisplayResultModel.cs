﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BOA.Web.Base;

namespace BOA.Web.InternetBanking.Religious.Models
{
    /// <summary>
    /// DisplayResultModel Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public class DisplayResultModel : BWizardModel
    {
        public string BusinessKey
        {
            get;
            set;
        }
    }
}
