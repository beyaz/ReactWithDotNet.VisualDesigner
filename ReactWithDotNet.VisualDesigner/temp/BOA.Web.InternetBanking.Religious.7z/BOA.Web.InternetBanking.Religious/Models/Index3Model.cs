﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BOA.Web.Base;
using BOA.Web.Base.Attributes;
using BOA.Types.InternetBanking;
using BOA.Types.Kernel.InternetBanking.CardModule.CardGeneral;

namespace BOA.Web.InternetBanking.Religious.Models
{
    /// <summary>
    /// Index3ModelCreditCardInfo Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public class Index3ModelCreditCardInfo
    {
        public string CreditCardNo { get; set; }
        public int AccountNumber { get; set; }
        public int AccountSuffix { get; set; }
    }
    /// <summary>
    /// Index3Model Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public class Index3Model : BWizardModel
    {
        public int? SourceAccountIndex
        {
            get;
            set;
        }

        public string SourceAccountInfo
        {
            get;
            set;
        }

        public int? SourceCreditCardIndex
        {
            get;
            set;
        }

        public Int16 PaymentType
        {
            get;
            set;
        }

        public AccountContract AccountContract
        {
            get;
            set;
        }

        public Index3ModelCreditCardInfo CreditCardContract
        {
            get;
            set;
        }

        public bool IsCreditCardVisible
        {
            get;
            set;
        }

        public bool IsNewAccountRequired
        {
            get;
            set;
        }

        public bool IsNewAccountCreated
        {
            get;
            set;
        }

        public bool IsCardSelectedOnInitialize
        {
            get;
            set;
        }
        public List<CardComponentItemDataContract> CustomCards
        {
            get;
            set;
        }
    }
}
