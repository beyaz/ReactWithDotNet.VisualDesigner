﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BOA.Web.InternetBanking.Religious.Types
{
    /// <summary>
    /// Constants Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public static class Constants
    {
        public static short HADJ_EXACT_REGISTRATION_ID = 3;
    }
}