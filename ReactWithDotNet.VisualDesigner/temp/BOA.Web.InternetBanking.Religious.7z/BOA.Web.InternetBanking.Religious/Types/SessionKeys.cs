﻿namespace BOA.Web.InternetBanking.Religious.Types
{
    /// <summary>
    /// SessionKeys Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public static class SessionKeys
    {
        public const string DeptInfo = "InternetBanking.Religious.DeptInfo";

        public const string RegistrationList = "InternetBanking.Religious.RegistrationList";

        public const string SelectedRegistration = "InternetBanking.Religious.SelectedRegistration";

        public const string IsCreditCardVisible = "InternetBanking.Religious.IsCreditCardVisible";

        public const string IsExistSARAccount = "InternetBanking.Religious.IsExistSARAccount";

        public const string IsExistSelectedAccount = "InternetBanking.Religious.IsExistSelectedAccount"; //

        public const string CustomerInfo = "InternetBanking.Religious.CustomerInfo";

        public const string IsExistCreditCard = "InternetBanking.Religious.IsExistCreditCard";

        public const string SharedAccountNumber = "SharedAccountNumber";

        public static readonly string WebUser = "WebUser";

        public const string CreditCardApplicationPreData = "BOA.InternetBanking.Religious.CreditCardApplicationPreData";

        public const string EligableCard = "BOA.InternetBanking.Religious.EligableCard";

        public const string CustomerName = "BOA.InternetBanking.Religious.CustomerName";
        public const string CustomerSurName = "BOA.InternetBanking.Religious.CustomerSurName";

    }
}
