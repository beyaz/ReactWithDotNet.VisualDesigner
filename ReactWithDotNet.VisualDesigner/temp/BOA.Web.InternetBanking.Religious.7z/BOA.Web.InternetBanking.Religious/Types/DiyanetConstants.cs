using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BOA.Web.InternetBanking.HadjFinalRegistration.Types
{
    /// <summary>
    /// DiyanetConstants Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public struct DiyanetConstants
    {
        public const string BankId = "15145";

        public const string ChannelId = "1";

        /// <summary>
        /// DiyanetGroup Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum DiyanetGroup
        {
            HadjPreRegistration = 1,
            HadjFinalRegistration = 3,
        }

        /// <summary>
        /// DiyanetInquiryType Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum DiyanetInquiryType
        {
            Loan = 0,
            Statement = 1,
        }

        /// <summary>
        /// FinalRegistrationQueryResult Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum FinalRegistrationQueryResult
        {
            CanPay = 3,
            AggredWithAgent = 4,
        }

        /// <summary>
        /// FinalRegistrationResult Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum FinalRegistrationResult
        {
            Successful = 1,
        }

        /// <summary>
        /// NotifyType Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum NotifyType
        {
            Cancel = 0,
            Payment = 1,
        }

        /// <summary>
        /// OperationType Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum OperationType
        {
            Insert = 0,
            Update = 1,
        }

        /// <summary>
        /// PaymentType Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum PaymentType
        {
            Cash = 0,
            Account = 1,
        }
    }
}
