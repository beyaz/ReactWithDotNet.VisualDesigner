﻿namespace BOA.Web.InternetBanking.Religious.Types
{
    /// <summary>
    /// HtmlIds Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public static class HtmlIds
    {
        public const string SourceAccountComponentIndex = "AccountComponent_ReligiousIndex";

        public const string SourceCardComponentIndex = "CardComponent_ReligiousIndex";

        /// <summary>
        /// PaymentType Class Definition
        /// Auto Generated Documentation
        /// BOA class standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public enum PaymentType
        {
            FromAccount = 1,
            CreditCard = 2
        }
    }
}
