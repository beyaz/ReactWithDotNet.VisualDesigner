﻿using BOA.Web.Base.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BOA.Web.InternetBanking.Religious.Types
{
    /// <summary>
    /// ReligiousHelper Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More Detail
    ///</summary>
    public static class ReligiousHelper
    {
        /// <summary>
        /// IsRefund Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration] kullanmaktadir.
        /// </summary>
        public static bool IsRefund()
        {
            var selectedRegistration = SessionManager.WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration] as BOA.Types.Kernel.PaymentSystems.Religious.RegistrationDefinitionContract;
            if (selectedRegistration != null)
            {
                return selectedRegistration.Code == (byte)BOA.Types.Kernel.PaymentSystems.Religious.ReligiousCommon.RegistrationType.UMRAH_REFUND ||
                        selectedRegistration.Code == (byte)BOA.Types.Kernel.PaymentSystems.Religious.ReligiousCommon.RegistrationType.HADJ_REFUND;
            }

            return false;
        }

        /// <summary>
        /// IsHadjPayment Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration] kullanmaktadir.
        /// </summary>
        public static bool IsHadjPayment()
        {
            var selectedRegistration = SessionManager.WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration] as BOA.Types.Kernel.PaymentSystems.Religious.RegistrationDefinitionContract;
            if (selectedRegistration != null)
            {
                return selectedRegistration.Code == (byte)BOA.Types.Kernel.PaymentSystems.Religious.ReligiousCommon.RegistrationType.HADJ_PAYMENT;
            }

            return false;
        }
    }
}