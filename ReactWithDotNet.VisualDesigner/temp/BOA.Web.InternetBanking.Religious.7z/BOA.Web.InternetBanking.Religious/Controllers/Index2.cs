﻿using BOA.Common.Types.Fraud;
using BOA.Types.InternetBanking;
using BOA.Types.Kernel.PaymentSystems.Religious;
using BOA.Web.Base;
using BOA.Web.Base.Types;
using BOA.Web.InternetBanking.Religious.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using MessageType = BOA.Web.Base.Types.MessageType;

namespace BOA.Web.InternetBanking.Religious.Controllers
{
    /// <summary>
    /// ReligiousController Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public partial class ReligiousController : BTransactionalWizardController
    {
        #region PrepareData
        /// <summary>
        /// PrepareIndex2Data Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult<BWizardModel> PrepareIndex2Data()
        {
            BActionResult<BWizardModel> returnObject = new BActionResult<BWizardModel>();
            Index2Model Index2Model = GetModel<Index2Model>(Index2View.Name);
            if (Index2Model == null)
            {
                Index2Model = new Index2Model();
                Index2Model.SelectedRegistrationIsContribution = false;
                Index2Model.Amount = new Money()
                {
                    FECCode = FecConstantsText.USD
                };
            }
            var SelectedRegistration = (RegistrationDefinitionContract)(WebContext.TransactionDataDictionary[Types.SessionKeys.SelectedRegistration]);
            Index2Model.SelectedRegistrationIsContribution = SelectedRegistration.Code == (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION;

            returnObject.Model = Index2Model;
            return returnObject;
        }

        #endregion
        #region Navigate
        /// <summary>
        /// Index2 Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        [HttpPost]
        public ActionResult Index2(Index2Model model)
        {
            return Navigate(model);
        }

        #endregion
        #region BeforeValidate
        /// <summary>
        /// BeforeValidateIndex2Data Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult<BWizardModel> BeforeValidateIndex2Data(BWizardModel model)
        {
            BActionResult<BWizardModel> returnObject = new BActionResult<BWizardModel>();
            Index2Model index2Model = GetModel<Index2Model>(Index2View.Name);
            Index2Model model2 = model as Index2Model;

            if (index2Model.SelectedRegistrationIsContribution)
            {
                if (model2.Amount == null || model2.Amount.Amount == 0)
                {
                    returnObject.AddMessage(Web.BusinessHelper.GetMessage("PaymentTrafficPaidAmountControl"), Web.BusinessHelper.GetMessage("PaymentsReligiousAmountWarningMessage"), MessageType.Error, null);
                    return returnObject;
                }
            }
            index2Model.Amount = model2.Amount;
            returnObject.Model = index2Model;
            return returnObject;
        }

        #endregion
        #region Validate
        /// <summary>
        /// ValidateIndex2Data Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult ValidateIndex2Data(BWizardModel model)
        {
            BActionResult returnObject = new BActionResult();

            return returnObject;
        }
        #endregion
    }
}
