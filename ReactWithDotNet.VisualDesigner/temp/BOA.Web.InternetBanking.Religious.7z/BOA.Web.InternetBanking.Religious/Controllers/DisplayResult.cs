﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BOA.Web.Base.Types;
using BOA.Web.Base;
using BOA.Web.InternetBanking.Religious.Models;
using BOA.Web.InternetBanking.Religious.Types;

namespace BOA.Web.InternetBanking.Religious.Controllers
{
    /// <summary>
    /// ReligiousController Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public partial class ReligiousController
    {
        #region PrepareData
        /// <summary>
        /// PrepareDisplayResultData Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public BActionResult<BWizardModel> PrepareDisplayResultData(BWizardModel displayResultModel)
        {
            BActionResult<BWizardModel> returnObject = new BActionResult<BWizardModel>();
            Index3Model index3Model = GetModel<Index3Model>(Index3View.Name);
            IndexModel indexModel = GetModel<IndexModel>(IndexView.Name);
            ViewBag.SourceAccountInfo = index3Model.SourceAccountInfo != null ? index3Model.SourceAccountInfo : "";
            ViewBag.RegistrationName = indexModel.SelectedRegistrationDefinitionContract != null ? indexModel.SelectedRegistrationDefinitionContract.RegistrationName : "";
            ViewBag.PaymentType = index3Model.PaymentType;
            ViewBag.IsRefund = ReligiousHelper.IsRefund();
            if (index3Model.AccountContract != null)
            {
                if (index3Model.AccountContract.AccountNumber != WebContext.UserContract.CustomerId)
                {
                    WebContext.UserDataDictionary[Types.SessionKeys.SharedAccountNumber] = index3Model.AccountContract.AccountNumber;
                }
                else if (WebContext.UserDataDictionary[Types.SessionKeys.SharedAccountNumber] != null)
                {
                    WebContext.UserDataDictionary[Types.SessionKeys.SharedAccountNumber] = null;
                }
            }


            returnObject.Model = displayResultModel;
            return returnObject;
        }
        #endregion
    }
}
