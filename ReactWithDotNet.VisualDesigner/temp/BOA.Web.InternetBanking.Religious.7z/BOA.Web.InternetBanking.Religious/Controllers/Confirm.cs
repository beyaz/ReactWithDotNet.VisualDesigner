﻿using BOA.Common.Types;
using BOA.Common.Types.Fraud;
using BOA.Types.InternetBanking;
using BOA.Types.InternetBanking.Payments;
using BOA.Types.Kernel.Customer;
using BOA.Types.Kernel.InternetBanking;
using BOA.Types.Kernel.PaymentSystems.Religious;
using BOA.Web.Base;
using BOA.Web.Base.Types;
using BOA.Web.InternetBanking.Extensions;
using BOA.Web.InternetBanking.Extensions.Models;
using BOA.Web.InternetBanking.Religious.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using MessageType = BOA.Web.Base.Types.MessageType;

namespace BOA.Web.InternetBanking.Religious.Controllers
{
    /// <summary>
    /// ReligiousController Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public partial class ReligiousController
    {
        #region PrepareData
        /// <summary>
        /// PrepareConfirmData Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult<BWizardModel> PrepareConfirmData()
        {
            BActionResult<BWizardModel> returnObject = new BActionResult<BWizardModel>();
            IndexModel indexModel = GetModel<IndexModel>(IndexView.Name);
            Index2Model index2Model = GetModel<Index2Model>(Index2View.Name);
            Index3Model index3Model = GetModel<Index3Model>(Index3View.Name);
            ConfirmModel confirmModel = GetModel<ConfirmModel>(ConfirmView.Name);
            if (confirmModel == null)
            {
                confirmModel = new ConfirmModel();
            }
            ViewBag.PaymentType = index3Model.PaymentType;
            ViewBag.PhoneNumber = index2Model.PhoneNumber;
            ViewBag.SourceAccountInfo = index3Model.SourceAccountInfo;
            ViewBag.IsNewAccountCreated = index3Model.IsNewAccountCreated;

            var SelectedRegistration = (RegistrationDefinitionContract)(WebContext.TransactionDataDictionary[Types.SessionKeys.SelectedRegistration]);
            bool isSelectedContribution = SelectedRegistration.Code == (byte)BOA.Types.Kernel.PaymentSystems.Religious.ReligiousCommon.RegistrationType.CONTRIBUTAION;
            ViewBag.CompanyCode = indexModel.CompanyCode;
            ViewBag.Amount = String.Format("{0} {1}", index2Model.Amount.Amount.ToString("N2"), FecConstantsText.USD);
            ViewBag.Description = SelectedRegistration.RegistrationName;
            var IsRefund = Types.ReligiousHelper.IsRefund();
            var queryResult = WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo] != null ? (BOA.Types.Kernel.PaymentSystems.Religious.PaymentContract)(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo]) : null;

            var webUser = WebContext.UserDataDictionary[Types.SessionKeys.WebUser] as WebUserContract;
            #region Customer Detail Info

            var profileRequest = new UserProfileRequest
            {
                CustomerId = webUser.CustomerId,
                PersonId = webUser.CustomerPersonId,
                MethodName = "GetIndividualPersonInfo"
            };

            var responsePerson = Execute<UserProfileRequest, GenericResponse<IndividualPersonInfoContract>>(profileRequest);
            if (!responsePerson.Success)
            {
                returnObject.AddMessage(BOA.Web.BusinessHelper.GetMessage("ProfileUserProfileErrorPersonalInfoText"), MessageType.Error, responsePerson.Results);
                return returnObject;
            }

            if (responsePerson.Value?.IndividualInfo == null)
            {
                returnObject.AddMessage(BOA.Web.BusinessHelper.GetMessage("ProfileUserProfileErrorPersonalInfoText"), MessageType.Error, responsePerson.Results);
                return returnObject;
            }

            #endregion

            string customerName = responsePerson.Value.IndividualInfo.Name;
            string customerSurName = responsePerson.Value.IndividualInfo.Surname;

            WebContext.TransactionDataDictionary[Types.SessionKeys.CustomerName] = customerName;
            WebContext.TransactionDataDictionary[Types.SessionKeys.CustomerSurName] = customerSurName;

            #region Initialize confirmModel.SecureConfirm
            string transactionTr = BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousReligiousText", MobileApproveConstants.TurkishId);
            string transactionEn = BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousReligiousText", MobileApproveConstants.EnglishId);
            List<Field> nonFinancialData = new List<Field> { };
            nonFinancialData.AddRange(DataHelper.GetNonFinancialFields(transactionTr, transactionEn));
            if (queryResult != null && (IsRefund || queryResult.TLAmount == 0) && !isSelectedContribution)
            {
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousCorporate", BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousReligious", Base.Utils.LocalizationHelper.LanguageId)));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousName", queryResult.Name));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousSurname", queryResult.Surname));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousTCIdentityNo", queryResult.IdentityNumber));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousPhoneNumber", ViewBag.PhoneNumber));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousPaymentTypeText", ViewBag.SourceAccountInfo));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields(IsRefund ? "GeneralRefundAmountLabel" : "PaymentsReligiousAmountText", queryResult.Amount.ToString("N2") + " " + queryResult.FecCode));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousDescription", queryResult.Description));
            }
            else if (isSelectedContribution)
            {
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousCorporate", BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousReligious", Base.Utils.LocalizationHelper.LanguageId)));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousName", customerName));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousSurname", customerSurName));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousCompanyCodeLabel", ViewBag.CompanyCode));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousPaymentTypeText", ViewBag.SourceAccountInfo));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousAmountText", ViewBag.Amount));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousDescription", ViewBag.Description));
            }
            else
            {
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousCorporate", BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousReligious", Base.Utils.LocalizationHelper.LanguageId)));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousName", queryResult.Name));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousSurname", queryResult.Surname));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousTCIdentityNo", queryResult.IdentityNumber));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousPhoneNumber", ViewBag.PhoneNumber));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousPaymentTypeText", ViewBag.SourceAccountInfo));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousAmountText", String.Format("{0} {1}", queryResult.Amount.ToString("N2"), queryResult.FecCode)));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousAmountTLText", String.Format("{0} {1}", queryResult.TLAmount.ToString("N2"), "TL")));
                nonFinancialData.AddRange(InformationHelperFinancial.GetNonFinancialFields("PaymentsReligiousDescription", queryResult.Description));
            }

            var secureConfirmParams = new SecureConfirmParameters
            {
                TransactionCode = TransactionContext.CurrentTransactionCode,
                SmsContent = String.Format(BOA.Web.BusinessHelper.GetMessage("InternetBankingPWFSMSMessage"), "{0}", Web.BusinessHelper.GetMessage("PaymentsReligiousReligiousText")),
                NonFinancialData = nonFinancialData
            };
            var secureConfirmResult = confirmModel.SecureConfirm == null ?
               this.InitializeSecureConfirm(secureConfirmParams) :
               this.UpdateSecureConfirm(confirmModel.SecureConfirm, secureConfirmParams);
            if (!secureConfirmResult.Success)
            {
                returnObject.AddMessage(BOA.Web.BusinessHelper.GetMessage("ErrMsgFetchScretWord"), BOA.Web.BusinessHelper.GetMessage("ErrMsgPrepareConfirm2DataSecretWordMethod"), secureConfirmResult.ResultList, MessageType.Error);
                return returnObject;
            }
            confirmModel.SecureConfirm = secureConfirmResult.Model;
            #endregion

            returnObject.Model = confirmModel;
            return returnObject;
        }

        #endregion
        #region Navigate
        /// <summary>
        /// Confirm Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        [HttpPost]
        public ActionResult Confirm(ConfirmModel model)
        {
            return Navigate(model);
        }

        #endregion
        #region Validate
        /// <summary>
        /// ValidateConfirmData Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult ValidateConfirmData(BWizardModel model)
        {
            BActionResult returnObject = new BActionResult();
            ConfirmModel confirmModel = GetModel<ConfirmModel>(ConfirmView.Name);
            if (confirmModel == null)
            {
                confirmModel = new ConfirmModel();
            }

            var validateSecureConfirmResult = this.ValidateSecureConfirm(confirmModel.SecureConfirm);
            if (!validateSecureConfirmResult.Success)
            {
                returnObject.AddMessage(Web.BusinessHelper.GetMessage("ErrMsgValidateConfirm2DataSecureConfirmMethod"), Web.BusinessHelper.GetMessage("ErrMsgValidateConfirm2DataSecureConfirmMethod"), validateSecureConfirmResult.ResultList, MessageType.Error);
                return returnObject;
            }
            return returnObject;
        }
        #endregion
    }
}
