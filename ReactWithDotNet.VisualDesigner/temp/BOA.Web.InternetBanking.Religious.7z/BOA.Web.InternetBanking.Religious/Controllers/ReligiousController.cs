﻿using BOA.Common.Types;
using BOA.Common.Types.Fraud;
using BOA.Types.InternetBanking;
using BOA.Types.InternetBanking.Payments;
using BOA.Types.Kernel.Customer;
using BOA.Types.Kernel.PaymentSystems.Religious;
using BOA.Types.WebBase;
using BOA.Web.Base;
using BOA.Web.Base.Types;
using BOA.Web.InternetBanking.Religious.Models;
using BOA.Web.InternetBanking.Religious.Types;
using System;
using System.Web.Configuration;
using MessageType = BOA.Web.Base.Types.MessageType;

namespace BOA.Web.InternetBanking.Religious.Controllers
{
    /// <summary>
    /// ReligiousController Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public partial class ReligiousController : BTransactionalWizardController
    {
        #region View Definitions
        BView Index2View = null;

        BView Index3View = null;

        BView ConfirmView = null;

        /// <summary>
        /// InitializeViews Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        protected override void InitializeViews()
        {
            IndexView.PrepareData = PrepareIndexData;
            IndexView.Validate = ValidateIndexData;
            Index2View = new BView("Index2");
            Index2View.PrepareData = PrepareIndex2Data;
            Index2View.BeforeValidate = BeforeValidateIndex2Data;
            Index2View.Validate = ValidateIndex2Data;
            ViewList.Add(Index2View);
            Index3View = new BView("Index3");
            Index3View.PrepareData = PrepareIndex3Data;
            Index3View.BeforeValidate = BeforeValidateIndex3Data;
            Index3View.Validate = ValidateIndex3Data;
            ViewList.Add(Index3View);
            ConfirmView = new BView("Confirm");
            ConfirmView.PrepareData = PrepareConfirmData;
            ConfirmView.Validate = ValidateConfirmData;
            ViewList.Add(ConfirmView);
            DisplayResultView.PrepareDisplayResultData = PrepareDisplayResultData;
        }

        /// <summary>
        /// GetNextView Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        protected override BView GetNextView(string fromStep)
        {
            if (fromStep == IndexView.Name)
            {
                return Index2View;
            }
            if (fromStep == Index2View.Name)
            {
                return Index3View;
            }
            if (fromStep == Index3View.Name)
            {
                return ConfirmView;
            }
            return IndexView;
        }

        #endregion
        #region Execute
        /// <summary>
        /// ExecuteAction Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        protected override BActionResult<BWizardModel> ExecuteAction()
        {
            BActionResult<BWizardModel> returnObject = new BActionResult<BWizardModel>();
            IndexModel indexModel = GetModel<IndexModel>(IndexView.Name);
            Index2Model index2Model = GetModel<Index2Model>(Index2View.Name);
            Index3Model index3Model = GetModel<Index3Model>(Index3View.Name);
            var queryResult = WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo] != null ? (BOA.Types.Kernel.PaymentSystems.Religious.PaymentContract)WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo] : null;
            bool IsCreditCardVisible = (bool)WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsCreditCardVisible];
            var SelectedRegistration = (BOA.Types.Kernel.PaymentSystems.Religious.RegistrationDefinitionContract)(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration]);
            bool isSelectedContribution = SelectedRegistration.Code == (byte)BOA.Types.Kernel.PaymentSystems.Religious.ReligiousCommon.RegistrationType.CONTRIBUTAION;
            short fecValue = isSelectedContribution ? BOA.Types.InternetBanking.FecConstants.USD : queryResult != null ? queryResult.FEC.Value : (short)0;
            var fecCode = isSelectedContribution ? BOA.Types.InternetBanking.FecConstantsText.USD : queryResult != null ? queryResult.FecCode : "";
            index3Model.PaymentType = isSelectedContribution ? (byte)HtmlIds.PaymentType.FromAccount : index3Model.PaymentType;

            #region Get Customer Info
            GenericResponse<CustomerInfoContract> responseCustomer = Web.BusinessHelper.GetCustomerInfoByAccountNumber(WebContext.UserContract.CustomerId);
            if (!responseCustomer.Success)
            {
                returnObject.AddMessage(Web.BusinessHelper.GetMessage("CustomerInfoNotFound"), MessageType.Error, responseCustomer.Results);
                return returnObject;
            }
            CustomerInfoContract customerInfoContract = responseCustomer.Value;
            var identityNumber = customerInfoContract.TaxNumber;
            var branchID = customerInfoContract.Branchid;
            #endregion


            #region Contract Doldurma
            PaymentContract DataContract = new PaymentContract();
            if (!isSelectedContribution)
            {
                DataContract = queryResult;
            }
            DataContract.IdentityNumber = identityNumber;
            DataContract.RemoteIdentityNumber = identityNumber;
            DataContract.RegistrationDefinitionId = isSelectedContribution ? (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION : DataContract.RegistrationDefinitionCode;
            DataContract.RegistrationDefinitionCode = isSelectedContribution ? (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION : DataContract.RegistrationDefinitionCode;
            DataContract.GSMNumber = isSelectedContribution ? "" : index2Model.PhoneNumber.Replace("(", "").Replace(")", "").Replace(" ", "");
            DataContract.WorkGroupId = ApplicationContext.User.WorkGroupId;
            DataContract.BranchId = branchID;
            DataContract.ChannelId = (byte)ApplicationContext.Channel.ChannelId;
            DataContract.TranDate = ApplicationContext.Channel.Today;
            DataContract.TranTime = new TimeSpan(ApplicationContext.Channel.Now.Hour, ApplicationContext.Channel.Now.Minute, ApplicationContext.Channel.Now.Second);
            DataContract.ResourceId = this.ResourceInfo.ResourceId;
            DataContract.Status = (byte)ReligiousCommon.PaymentStatus.Active;
            DataContract.RegistrationName = indexModel.SelectedRegistrationDefinitionContract.RegistrationName;
            DataContract.SecurityCode = indexModel.SecurityCode != null ? indexModel.SecurityCode : "";
            DataContract.RemoteSecurityCode = indexModel.SecurityCode ?? "";
            DataContract.OrgSaveType = ReligiousHelper.IsHadjPayment() ? indexModel.OrgSaveType : null;
            DataContract.TourCode = isSelectedContribution ? indexModel.CompanyCode : (indexModel.TourCode ?? "");
            DataContract.Name = WebContext.TransactionDataDictionary[Types.SessionKeys.CustomerName] != null ? (string)WebContext.TransactionDataDictionary[Types.SessionKeys.CustomerName] : "";
            DataContract.Surname = WebContext.TransactionDataDictionary[Types.SessionKeys.CustomerSurName] != null ? (string)WebContext.TransactionDataDictionary[Types.SessionKeys.CustomerSurName] : "";

            if (isSelectedContribution)
            {
                DataContract.Amount = index2Model.Amount.Amount;
                DataContract.FEC = FecConstants.USD;
                DataContract.FromFEC = FecConstants.USD;
            }

            int accountNumber = 0;
            short accountSuffix = 0, branchId = 0, fec = 0;
            if (index3Model.PaymentType == (byte)HtmlIds.PaymentType.FromAccount || !IsCreditCardVisible || ReligiousHelper.IsRefund())
            {
                DataContract.PaymentType = (byte)ReligiousCommon.PaymentType.Account;
                DataContract.AccountInfo = new PaymentAccountContract();
                DataContract.AccountInfo.AccountNumber = index3Model.AccountContract.AccountNumber;
                DataContract.AccountInfo.AccountSuffix = index3Model.AccountContract.AccountSuffix;
                DataContract.AccountInfo.BranchId = index3Model.AccountContract.BranchId;
                DataContract.AccountInfo.FEC = index3Model.AccountContract.FEC;
                accountNumber = DataContract.AccountInfo.AccountNumber;
                accountSuffix = DataContract.AccountInfo.AccountSuffix;
                branchId = DataContract.AccountInfo.BranchId;
            }
            else
            {
                DataContract.PaymentType = (byte)ReligiousCommon.PaymentType.CreditCard;
                DataContract.CardInfo = new PaymentCardContract();
                DataContract.CardInfo.CardNumber = index3Model.CreditCardContract.CreditCardNo;
                DataContract.CardInfo.AccountNumber = index3Model.CreditCardContract.AccountNumber;
                DataContract.CardInfo.AccountSuffix = (short)index3Model.CreditCardContract.AccountSuffix;
                accountNumber = DataContract.CardInfo.AccountNumber;
                accountSuffix = DataContract.CardInfo.AccountSuffix;
                branchId = DataContract.CardInfo.BranchId;
            }
            #endregion
            ReligiousRequest religiousRequest = new ReligiousRequest();
            religiousRequest.PaymentContract = DataContract;
            religiousRequest.FinancialData = new FinancialContract();
            religiousRequest.FinancialData.Amount = isSelectedContribution ? index2Model.Amount.Amount : DataContract.Amount;
            religiousRequest.FinancialData.FEC = fecValue;
            religiousRequest.FinancialData.ToName = BOA.Types.InternetBanking.Payments.Constants.Diyanet;
            religiousRequest.FinancialData.UserId = WebContext.UserContract.UserId;
            religiousRequest.FinancialData.IsReverse = ReligiousHelper.IsRefund(); //iade işlemler için limitten düşülmesin.
            religiousRequest.FinancialData.SessionId = WebContext.IISSessionId;
            religiousRequest.MainAccountNumber = accountNumber;
            religiousRequest.MainSuffix = accountSuffix;
            religiousRequest.FEC = isSelectedContribution ? FecConstants.USD : DataContract.FEC;
            religiousRequest.BranchId = branchId;
            GenericResponse<Int32> paymentResponse = Execute<ReligiousRequest, GenericResponse<Int32>>(religiousRequest, true);
            if (!paymentResponse.Success)
            {
                returnObject.AddMessage("", MessageType.Error, paymentResponse.Results);
                return returnObject;
            }
            ViewBag.IsSuccess = true;
            returnObject.Model = new DisplayResultModel
            {
                BusinessKey = paymentResponse.BusinessKey.ToString()
            };
            return returnObject;
        }
        #endregion
    }
}
