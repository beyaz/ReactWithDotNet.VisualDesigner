﻿using BOA.Common.Types;
using BOA.Types.InternetBanking;
using BOA.Types.InternetBanking.Payments;
using BOA.Types.Kernel.Customer;
using BOA.Types.Kernel.General;
using BOA.Types.Kernel.InternetBanking;
using BOA.Types.Kernel.PaymentSystems.Religious;
using BOA.Web.Base;
using BOA.Web.Base.Types;
using BOA.Web.InternetBanking.Religious.Models;
using BOA.Web.InternetBanking.Religious.Types;
using System.Collections.Generic;
using BOA.Web.InternetBanking.Extensions.Models;
using BOA.Web.InternetBanking.Extensions;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Mvc;

namespace BOA.Web.InternetBanking.Religious.Controllers
{
    /// <summary>
    /// Index
    /// </summary>
    public partial class ReligiousController : BTransactionalWizardController
    {
        #region PrepareData
        /// <summary>
        /// PrepareIndexData
        /// </summary>
        /// <returns></returns>
        private BActionResult<BWizardModel> PrepareIndexData()
        {
            var returnObject = new BActionResult<BWizardModel>();
            TransactionContext.CurrentTransactionCode = TransactionCode.RELIGIOUS;
            var indexModel = GetModel<IndexModel>(IndexView.Name);
            if (indexModel == null)
            {
                indexModel = new IndexModel();
            }
            #region LoadRegistrationDefinition Info
            List<RegistrationDefinitionContract> registrationDefinitionList = LoadRegistrationDefinition();
            if (registrationDefinitionList == null)
            {
                AddModelErrorMessage("RegistrationDefinitionId", Web.BusinessHelper.GetMessage("PaymentsReligiousRegistrationDefinitionErrorText"));
                return returnObject;
            }
            var RegistrationDefinitionView = new List<RegistrationDefinitionContract>();
            foreach (var item in registrationDefinitionList)
            {
                RegistrationDefinitionView.Add(new RegistrationDefinitionContract
                {
                    RegistrationDefinitionId = item.RegistrationDefinitionId,
                    Code = item.Code,
                    RegistrationName = item.RegistrationName + " (" + item.ProcessStatusName + ")"
                });
            }
            WebContext.TransactionDataDictionary["RegistrationList"] = RegistrationDefinitionView;
            if (!WebContext.TransactionDataDictionary.ContainsKey(Types.SessionKeys.RegistrationList))
            {
                WebContext.TransactionDataDictionary.Add(Types.SessionKeys.RegistrationList, registrationDefinitionList);
            }
            else
            {
                WebContext.TransactionDataDictionary[Types.SessionKeys.RegistrationList] = registrationDefinitionList;
            }
            #endregion
            ViewBag.RegistrationDefinitionList = RegistrationDefinitionView;

            List<ReligiousAgreementContract> aggrementList = new List<ReligiousAgreementContract>();
            var agreementRequest = new ReligiousAgreementRequest()
            {
                MethodName = "GetReligiousAgreement",
                LanguageId = Base.Utils.LocalizationHelper.LanguageId,
                canGetWithData = true
            };
            var response = Execute<ReligiousAgreementRequest, GenericResponse<List<ReligiousAgreementContract>>>(agreementRequest);
            if (response.Success)
            {
                aggrementList = response.Value;
            }
            indexModel.AggrementList = aggrementList;

            #region Initialize confirm2Model.SecureConfirm

            indexModel.SecureConfirmForAgreementModel = new SecureConfirmAgreementModel();
            indexModel.SecureConfirmForAgreementModel.SecurityApproveDocumentContractList = new List<SecurityApproveDocumentContract>();
            indexModel.SecureConfirmForAgreementModel.AgreementDataList = new List<SecureConfirmAgreementData>();

            if (indexModel.AggrementList != null && indexModel.AggrementList.Count > 0)
            {
                for (int i = 0; i < indexModel.AggrementList.Count; i++)
                {
                    SecurityApproveDocumentContract securityApproveDocumentContract = new SecurityApproveDocumentContract()
                    {
                        PdfContent = indexModel.AggrementList[i].DocumentContent,
                        DocumentName = indexModel.AggrementList[i].Name,
                        ShowRejectButton = false,
                        ShowApproveButton = false,
                        ShowSwitch = true,
                        ShowTimer = true,
                        ShowShareButton = true
                    };

                    SecureConfirmAgreementData agreementData = new SecureConfirmAgreementData
                    {
                        AgreementData = indexModel.AggrementList[i].DocumentContent,
                        AgreementName = indexModel.AggrementList[i].Name,
                        IsRequired = true
                    };

                    indexModel.SecureConfirmForAgreementModel.SecurityApproveDocumentContractList.Add(securityApproveDocumentContract);
                    indexModel.SecureConfirmForAgreementModel.AgreementDataList.Add(agreementData);

                }
                var secureConfirmParams = new SecureConfirmAgreementParameters()
                {
                    SecurityApproveDocumentContractList = indexModel.SecureConfirmForAgreementModel.SecurityApproveDocumentContractList,
                    TransactionCode = TransactionContext.CurrentTransactionCode,
                };

                var secureConfirmResult = indexModel.SecureConfirmForAgreementModel != null ?
                this.UpdateSecureConfirmAgreement(indexModel.SecureConfirmForAgreementModel, secureConfirmParams) :
                this.InitializeSecureConfirmAgreement(secureConfirmParams);

                if (!secureConfirmResult.Success)
                {
                    returnObject.AddMessage(Web.BusinessHelper.GetMessage("ErrMsgFetchScretWord"), "", secureConfirmResult.ResultList, MessageType.Error);
                    return returnObject;
                }

                indexModel.SecureConfirmForAgreementModel = secureConfirmResult.Model;
            }


            #endregion
            returnObject.Model = indexModel;
            return returnObject;
        }

        #endregion
        #region Navigate
        /// <summary>
        /// Navigate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Index(IndexModel model)
        {
            return Navigate(model);
        }

        #endregion

        #region Validate
        /// <summary>
        /// ValidateIndexData
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private BActionResult ValidateIndexData(BWizardModel model)
        {
            var returnObject = new BActionResult();
            var indexModel = GetModel<IndexModel>(IndexView.Name);
            if (indexModel == null)
            {
                indexModel = new IndexModel();
            }
            var RegistrationList = (List<RegistrationDefinitionContract>)WebContext.TransactionDataDictionary[Types.SessionKeys.RegistrationList];

            indexModel.SelectedRegistrationDefinitionContract = RegistrationList.Find(y => y.RegistrationDefinitionId == indexModel.RegistrationDefinitionId);

            if (indexModel == null || RegistrationList == null ||
                indexModel.SelectedRegistrationDefinitionContract == null)
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("WebBaseDefaultTitleText"));
                return returnObject;
            }

            var validateSecureConfirmAgreementResult = this.ValidateSecureConfirmAgreement(indexModel.SecureConfirmForAgreementModel);
            if (!validateSecureConfirmAgreementResult.Success)
            {
                returnObject.AddMessage(Web.BusinessHelper.GetMessage("ErrMsgValidateConfirm2DataSecureConfirmMethod"), Web.BusinessHelper.GetMessage("ErrMsgValidateConfirm2DataSecureConfirmMethod"), validateSecureConfirmAgreementResult.ResultList, MessageType.Error);
                return returnObject;
            }

            if (indexModel.SelectedRegistrationDefinitionContract.Code != (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION)
            {
                var isValidIdentityNumber = Common.Helpers.ValidationHelper.IsValidTaxOrTcNumber(indexModel.TRIdentificationNo);
                if (!isValidIdentityNumber)
                {
                    returnObject.AddMessage(Web.BusinessHelper.GetMessage("DyntBehalfTxt"), Web.BusinessHelper.GetMessage("ErrMsgValidateConfirm2DataSecureConfirmMethod"), null, MessageType.Info);
                    return returnObject;
                }
            }
            #region Kontroller
            if (indexModel.SelectedRegistrationDefinitionContract.Code != (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION)
            {
                if (Common.Helpers.ValidationHelper.IsValidTaxOrTcNumber(indexModel.TRIdentificationNo) == false
                && Base.Configuration.ConfigurationManager.ApplicationEnvironmentSection.ApplicationEnvironment.Environment == ApplicationEnvironment.Production)
                {
                    AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousFailureTCIdentityNo"));
                    return returnObject;
                }
            }
            if (!indexModel.RegistrationDefinitionId.HasValue || indexModel.RegistrationDefinitionId == 0)
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousRegistrationDefinitionErrorText"));
                return returnObject;
            }
            if (indexModel.SelectedRegistrationDefinitionContract.Code == (byte)ReligiousCommon.RegistrationType.UMRAH_PAYMENT &&
                string.IsNullOrEmpty(indexModel.TourCode))
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousTourCodeErrorText"));
                return returnObject;
            }
            if (!RegistrationList.Exists(y => y.RegistrationDefinitionId == indexModel.RegistrationDefinitionId))
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousRegistrationDefinitionErrorText"));
                return returnObject;
            }
            if (!RegistrationList.Exists(y => y.RegistrationDefinitionId == indexModel.RegistrationDefinitionId && y.ProcessStatus == true))
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousRegistrationDefinitionProcessStatusErrorText"));
                return returnObject;
            }

            if (indexModel.SelectedRegistrationDefinitionContract.Code == (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION &&
                string.IsNullOrEmpty(indexModel.CompanyCode))
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousCompanyCodeWarningMessage"));
                return returnObject;
            }


            if (indexModel.SelectedRegistrationDefinitionContract.Code == (byte)ReligiousCommon.RegistrationType.HADJ_PAYMENT)
            {
                indexModel.OrgSaveType = 1;
            }

            WebContext.TransactionDataDictionary[Types.SessionKeys.SelectedRegistration] = indexModel.SelectedRegistrationDefinitionContract;

            if (!ValidateForRefund(indexModel))
            {
                return returnObject;
            }

            #endregion
            if (indexModel.SelectedRegistrationDefinitionContract.Code != (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION)
            {
                #region Borç sorgulama
                var queryRequest = new ReligiousInfoRequest
                {
                    MethodName = "GetDebt",
                    MainAccountNumber = WebContext.UserContract.CustomerId,
                    PaymentContract = new PaymentContract
                    {
                        IdentityNumber = indexModel.TRIdentificationNo,
                        TourCode = indexModel.TourCode,
                        FEC = indexModel.SelectedRegistrationDefinitionContract.FEC,
                        FecCode = indexModel.SelectedRegistrationDefinitionContract.FecCode,
                        RegistrationDefinitionId = indexModel.RegistrationDefinitionId,
                        RegistrationDefinitionCode = indexModel.SelectedRegistrationDefinitionContract.Code,
                        OrgSaveType = ReligiousHelper.IsHadjPayment() ? indexModel.OrgSaveType : null,
                        SecurityCode = indexModel.SecurityCode,
                        RemoteSecurityCode = indexModel.SecurityCode
                    }
                };

                var queryResponse = Execute<ReligiousInfoRequest, GenericResponse<PaymentContract>>(queryRequest);
                if (!queryResponse.Success)
                {
                    returnObject.AddMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousErrorIndex1"), MessageType.Error, queryResponse.Results);
                    return returnObject;
                }
                if (queryResponse.Value == null)
                {
                    AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousErrorIndex2"));
                    return returnObject;
                }
                if (!queryResponse.Value.IsPayable)
                {
                    AddGenericErrorMessage(queryResponse.Value.StatusText);
                    return returnObject;
                }
                if (queryResponse.Value.Amount == 0)
                {
                    AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousDebtAmountCanNotBeZero"));
                    return returnObject;
                }
                #endregion
                WebContext.TransactionDataDictionary[Types.SessionKeys.DeptInfo] = queryResponse.Value;
            }

            return returnObject;
        }

        #endregion
        #region Methods
        /// <summary>
        /// LoadRegistrationDefinition
        /// </summary>
        /// <returns></returns>
        private List<RegistrationDefinitionContract> LoadRegistrationDefinition()
        {
            var request = new ReligiousInfoRequest
            {
                RegistrationDefinitionContract = new RegistrationDefinitionContract
                {
                    ChannelId = (byte)ApplicationContext.Channel.ChannelId
                },
                MethodName = "SelectForPayment"
            };
            var response = Execute<ReligiousInfoRequest, GenericResponse<List<RegistrationDefinitionContract>>>(request);

            return response.Success ? response.Value : null;
        }

        /// <summary>
        /// RegistrationDefinitionCode
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult RegistrationDefinitionCode(int? id)
        {
            return Json(new BJsonResult
            {
                Data = ((List<RegistrationDefinitionContract>)WebContext.TransactionDataDictionary["RegistrationList"])?.Find(x => x.RegistrationDefinitionId == id)?.Code ?? 0
            });
        }

        /// <summary>
        /// ValidateForRefund
        /// </summary>
        /// <param name="indexModel"></param>
        /// <returns></returns>
        private bool ValidateForRefund(IndexModel indexModel)
        {
            if (!ReligiousHelper.IsRefund())
                return true;

            if (string.IsNullOrWhiteSpace(indexModel.SecurityCode) || !Regex.IsMatch(indexModel.SecurityCode.Trim(), @"^[a-zA-Z0-9]{0,10}$"))
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousSecurityCodeWarningMessage"));
                return false;
            }

            GenericResponse<CustomerInfoContract> responseCustomer = Web.BusinessHelper.GetCustomerInfoByAccountNumber(WebContext.UserContract.CustomerId);
            if (!responseCustomer.Success || string.IsNullOrWhiteSpace(responseCustomer.Value?.TaxNumber))
            {
                AddGenericErrorMessage(string.Format(Web.BusinessHelper.GetMessage("CustomerInfoNotFound"), ""));
                return false;
            }

            if (indexModel.TRIdentificationNo != responseCustomer.Value?.TaxNumber)
            {
                AddGenericErrorMessage(Web.BusinessHelper.GetMessage("PaymentsReligiousOnlyOwnTCKNWarningMessage"));
                return false;
            }

            WebContext.TransactionDataDictionary[Types.SessionKeys.CustomerInfo] = responseCustomer.Value;

            return true;
        }
        #endregion
    }
}
