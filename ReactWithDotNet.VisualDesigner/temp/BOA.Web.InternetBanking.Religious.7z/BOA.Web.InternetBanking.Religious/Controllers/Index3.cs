﻿using BOA.Common.Types;
using BOA.Types.InternetBanking;
using BOA.Types.InternetBanking.CardModule;
using BOA.Types.InternetBanking.CreditCard;
using BOA.Types.InternetBanking.Payments;
using BOA.Types.Kernel.Customer;
using BOA.Types.Kernel.General;
using BOA.Types.Kernel.InternetBanking.CardModule.CardGeneral;
using BOA.Types.WebBase;
using BOA.Web.Base;
using BOA.Web.Base.Types;
using BOA.Web.Base.Utils;
using BOA.Web.InternetBanking.Religious.Models;
using BOA.Web.InternetBanking.Religious.Types;
using System;
using BOA.Web.InternetBanking.Extensions;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using CreditCardApplicationGetDetailRequest = BOA.Types.InternetBanking.CreditCard.CreditCardApplicationGetDetailRequest;
using NewCardApplicationPreDataContract = BOA.Types.InternetBanking.CreditCard.NewCardApplicationPreDataContract;
using SessionKeys = BOA.Web.InternetBanking.Religious.Types.SessionKeys;
using BOA.Types.Kernel.PaymentSystems.Religious;

namespace BOA.Web.InternetBanking.Religious.Controllers
{
    /// <summary>
    /// ReligiousController Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public partial class ReligiousController : BTransactionalWizardController
    {
        #region PrepareData
        /// <summary>
        /// PrepareIndex3Data Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult<BWizardModel> PrepareIndex3Data()
        {
            BActionResult<BWizardModel> returnObject = new BActionResult<BWizardModel>();
            Index3Model Index3Model = GetModel<Index3Model>(Index3View.Name);
            Index2Model Index2Model = GetModel<Index2Model>(Index2View.Name);
            if (Index3Model == null)
            {
                Index3Model = new Index3Model();
            }

            ViewBag.IsCreditCardVisible = false;
            WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsCreditCardVisible] = ViewBag.IsCreditCardVisible;

            GenericResponse<List<ParameterContract>> responsePaymentType = BOA.Web.BusinessHelper.GetParameter("IsVisibleCreditCard");
            if (responsePaymentType.Value != null && responsePaymentType.Value.Count > 0)
            {
                if (responsePaymentType.Value.FirstOrDefault().ParamCode == "1")
                    ViewBag.IsCreditCardVisible = true;
                else
                    ViewBag.IsCreditCardVisible = false;

                WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsCreditCardVisible] = ViewBag.IsCreditCardVisible;
            }

            Index3Model.CustomCards = CreditCardListCustom();

            var predataResult = GetPreData();
            var creditCardControl = false;
            if (predataResult.Model != null)
            {
                var EligibleCardDataList = predataResult.Model.EligibleCardDataList;
                for (int i = 0; i < EligibleCardDataList.Count(); i++)
                {
                    if (EligibleCardDataList[i].IndividualCreditFlag == false && EligibleCardDataList[i].IsDebitCard == false)
                    {
                        creditCardControl = true;
                        break;
                    }
                }
            }

            var cardApplications = WebResourceNodeHelper.GetUserResource();
            var cardApplicationControl = cardApplications.Exists(x => x.ResourceCode == ResourceCodeConstants.CardApplication);

            if (cardApplicationControl == true && creditCardControl == true)
            {
                var text = WebResourceNodeHelper.GetResourceLinkText(ResourceCodeConstants.CardApplication);
                if (!string.IsNullOrEmpty(text))
                {
                    ViewBag.Message = string.Format(CultureInfo.CurrentCulture, Web.BusinessHelper.GetMessage("PaymentAvailableCreditCardWarningMessage"), text);
                }
            }

            LoadPaymentComponentsData();
            returnObject.Model = Index3Model;
            return returnObject;
        }

        #endregion
        #region Custom Cards
        /// <summary>
        /// CreditCardListCustom
        /// </summary>
        /// <returns></returns>
        public List<CardComponentItemDataContract> CreditCardListCustom()
        {
            List<CardComponentItemDataContract> customCardList = new List<CardComponentItemDataContract>();

            var request = new CreditCardListRequest
            {
                CustomerId = WebContext.UserContract.CustomerId,
                MainAccountNumber = WebContext.UserContract.CustomerId,
                MethodName = OrchestrationMethod.FetchCardListOfCustomer,
                FetchOnlySupplementaryCardForCorporateCard = true
            };
            var response = Execute<CreditCardListRequest, GenericResponse<List<CardContract>>>(request, true);
            if (response != null)
            {
                List<CardContract> cardList = response.Value;

                foreach (var card in cardList)
                {
                    if (card.CreditCardStateIsN)
                    {
                        var cardComponentItemDataContract = new CardComponentItemDataContract();
                        cardComponentItemDataContract.AccountNumber = card.AccountNumber;
                        cardComponentItemDataContract.AvailableLimit = card.AvailableLimit;
                        cardComponentItemDataContract.CardHolderName = card.CardHolderName;
                        cardComponentItemDataContract.CardMenuContractDisplayName = card.CardMenuContractDisplayName;
                        cardComponentItemDataContract.CardOwnerName = card.CardOwnerName;
                        cardComponentItemDataContract.CreditCardNo = card.CreditCardNo;
                        cardComponentItemDataContract.MainOrSupplementary = card.MainOrSupplementary;
                        cardComponentItemDataContract.PrimaryCardNo = card.PrimaryCardNo;
                        cardComponentItemDataContract.ProductType = card.ProductType;
                        cardComponentItemDataContract.ProductTypeName = card.ProductTypeName;
                        cardComponentItemDataContract.SecuredCardNo = card.SecuredCardNo;
                        cardComponentItemDataContract.TotalLimit = card.TotalLimit;
                        customCardList.Add(cardComponentItemDataContract);
                    }
                }
            }
            return customCardList;
        }
        #endregion
        #region Navigate
        /// <summary>
        /// Index3 Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        [HttpPost]
        public ActionResult Index3(Index3Model model)
        {
            return Navigate(model);
        }

        #endregion
        #region BeforeValidate
        /// <summary>
        /// BeforeValidateIndex3Data Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult<BWizardModel> BeforeValidateIndex3Data(BWizardModel model)
        {
            BActionResult<BWizardModel> returnObject = new BActionResult<BWizardModel>();
            Index3Model Index3Model = model as Index3Model;
            IndexModel IndexModel = this.GetModel<IndexModel>(IndexView.Name);
            Index2Model index2Model = this.GetModel<Index2Model>(Index2View.Name);

            BOA.Types.Kernel.PaymentSystems.Religious.PaymentContract dept = (BOA.Types.Kernel.PaymentSystems.Religious.PaymentContract)WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo];
            bool IsCreditCardVisible = (bool)WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsCreditCardVisible];
            var queryResult = WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo] != null ? (BOA.Types.Kernel.PaymentSystems.Religious.PaymentContract)(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo]) : null;
            var SelectedRegistration = (BOA.Types.Kernel.PaymentSystems.Religious.RegistrationDefinitionContract)(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration]);
            bool isSelectedContribution = SelectedRegistration.Code == (byte)BOA.Types.Kernel.PaymentSystems.Religious.ReligiousCommon.RegistrationType.CONTRIBUTAION;
            short fecValue = isSelectedContribution ? BOA.Types.InternetBanking.FecConstants.USD : queryResult != null ? queryResult.FEC.Value : (short)0;
            var fecCode = isSelectedContribution ? BOA.Types.InternetBanking.FecConstantsText.USD : queryResult != null ? queryResult.FecCode : "";
            if (ReligiousHelper.IsRefund())
            {
                AccountContract accountContract = this.GetAccountComponentSelectedData(Index3Model.SourceAccountIndex?.ToString(), HtmlIds.SourceAccountComponentIndex);
                if (accountContract == null)
                {
                    if (!Convert.ToBoolean(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSelectedAccount]))
                    {
                        if (!Index3Model.IsNewAccountRequired)
                        {
                            AddGenericErrorMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousNotFoundAccountErrorText", BOA.Web.Base.Utils.LocalizationHelper.LanguageId));
                            return returnObject;
                        }
                    }
                    else
                    {
                        AddGenericErrorMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousNotFoundAccountErrorText", BOA.Web.Base.Utils.LocalizationHelper.LanguageId));
                        return returnObject;
                    }
                }
                else
                {
                    Index3Model.SourceAccountInfo = accountContract.FullAccountName;
                    Index3Model.AccountContract = accountContract;
                }

                if (Index3Model.IsNewAccountRequired && !Convert.ToBoolean(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSelectedAccount]))
                {
                    if (!IsAuthorizedToOpenNewAccount())
                    {
                        AddGenericErrorMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "WebBaseNotAuthorized", BOA.Web.Base.Utils.LocalizationHelper.LanguageId));
                        return returnObject;
                    }

                    int newAccountNumber = 0;
                    var request = CreateOpenAccountRequet(accountContract, out newAccountNumber, fecValue);
                    GenericResponse<WebOpenAccountCurrentResponse> response = Execute<WebOpenAccountCurrentRequest, GenericResponse<WebOpenAccountCurrentResponse>>(request);
                    if (!response.Success)
                    {
                        returnObject.AddMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "AccountsOpenAccountOpenAccountErrorText", BOA.Web.Base.Utils.LocalizationHelper.LanguageId), MessageType.Error, response.Results);
                        return returnObject;
                    }

                    var newAccountResponse = BusinessHelper.GetAccount(newAccountNumber, response.Value.AccountSuffix);
                    if (!newAccountResponse.Success)
                    {
                        returnObject.AddMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "AccountsOpenAccountOpenAccountErrorText", BOA.Web.Base.Utils.LocalizationHelper.LanguageId), MessageType.Error, newAccountResponse.Results);
                        return returnObject;
                    }

                    WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSelectedAccount] = true;

                    var newAccountAvailable = newAccountResponse.Value?.FirstOrDefault(x => x.FEC == fecValue); ////r
                    if (newAccountAvailable != null)
                    {
                        Index3Model.SourceAccountInfo = newAccountAvailable.FullAccountName;
                        Index3Model.AccountContract = newAccountAvailable;
                    }
                    else
                    {
                        returnObject.AddMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "AccountsOpenAccountOpenAccountErrorText", BOA.Web.Base.Utils.LocalizationHelper.LanguageId), MessageType.Error, newAccountResponse.Results);
                        return returnObject;
                    }

                    Index3Model.IsNewAccountCreated = true;
                }
            }
            else
            {
                #region Bakiye kontrol
                if (Index3Model.PaymentType == (byte)HtmlIds.PaymentType.FromAccount || !IsCreditCardVisible)
                {
                    AccountContract accountContract = this.GetAccountComponentSelectedData(Index3Model.SourceAccountIndex.ToString(), HtmlIds.SourceAccountComponentIndex);

                    if (accountContract == null)
                    {
                        AddGenericErrorMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousNotFoundAccountErrorText", BOA.Web.Base.Utils.LocalizationHelper.LanguageId));
                        return returnObject;
                    }
                    if (SelectedRegistration.Code == (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION)
                    {
                        if (accountContract.AvailableBalance.Value < index2Model.Amount.Amount)
                        {
                            AddGenericErrorMessage(string.Format(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousNoAvailableAccountWarningMessage", BOA.Web.Base.Utils.LocalizationHelper.LanguageId), fecCode));
                            return returnObject;
                        }
                    }
                    else
                    {
                        if (accountContract.AvailableBalance.Value < (decimal)dept.Amount)
                        {
                            AddGenericErrorMessage(string.Format(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousNoAvailableAccountWarningMessage", BOA.Web.Base.Utils.LocalizationHelper.LanguageId), fecCode));
                            return returnObject;
                        }
                    }
                    Index3Model.SourceAccountInfo = accountContract.FullAccountName;
                    Index3Model.AccountContract = accountContract;
                }
                else if (Index3Model.PaymentType == (byte)HtmlIds.PaymentType.CreditCard)
                {
                    if (Index3Model.SourceCreditCardIndex != null)
                    {
                        var creditCardContractSender = this.GetCreditCardListComponentSelectedDataRefactored(Index3Model.SourceCreditCardIndex.ToString(), HtmlIds.SourceCardComponentIndex.ToString());
                        if (creditCardContractSender == null)
                        {
                            AddGenericErrorMessage(Resources.Strings.NotFoundCardErrorText);
                            return returnObject;
                        }
                        else
                        {
                            if (creditCardContractSender.AvailableLimit <= 0)
                            {
                                AddGenericErrorMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "GeneralCreditCardLimitInsufficientWarningMessage", BOA.Web.Base.Utils.LocalizationHelper.LanguageId));
                                return returnObject;
                            }
                            Index3Model.SourceAccountInfo = creditCardContractSender.SecuredCardNo;
                            Index3Model.CreditCardContract = new Index3ModelCreditCardInfo
                            {
                                CreditCardNo = creditCardContractSender.CreditCardNo,
                                AccountNumber = creditCardContractSender.AccountNumber,
                                AccountSuffix = creditCardContractSender.AccountSuffix

                            };//

                        }
                    }
                    else
                    {
                        AddGenericErrorMessage(Resources.Strings.NotFoundCardErrorText);
                        return returnObject;
                    }
                }
                else
                {
                    AddGenericErrorMessage(BOA.Messaging.MessagingHelper.GetMessage("InternetBanking", "PaymentsReligiousNotSelectedPaymentTypeMessage", BOA.Web.Base.Utils.LocalizationHelper.LanguageId));
                    return returnObject;
                }
                #endregion
            }


            returnObject.Model = Index3Model;
            return returnObject;
        }

        #endregion
        #region Validate
        /// <summary>
        /// ValidateIndex3Data Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        private BActionResult ValidateIndex3Data(BWizardModel model)
        {
            BActionResult returnObject = new BActionResult();
            Index3Model Index3Model = GetModel<Index3Model>(Index3View.Name);
            IndexModel indexModel = GetModel<IndexModel>(IndexView.Name);
            return returnObject;
        }
        #endregion


        /// <summary>
        /// Kart Başvuru ekranındaki listeyi getirir.
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public BActionResult<NewCardApplicationPreDataContract> GetPreData()
        {
            var result = new BActionResult<NewCardApplicationPreDataContract>();

            var preData = WebContext.TransactionDataDictionary[SessionKeys.CreditCardApplicationPreData] as NewCardApplicationPreDataContract;

            if (preData == null)
            {
                var webUser = WebContext.UserDataDictionary[Types.SessionKeys.WebUser] as BOA.Types.InternetBanking.WebUserContract;
                var requestPreData = new CreditCardApplicationGetDetailRequest
                {
                    MethodName = "GetNewCardApplicationPreData",
                    CustomerPersonId = webUser.CustomerPersonId,
                    PersonId = webUser.CustomerPersonId,
                    CustomerId = webUser.CustomerId,
                    LanguageId = LocalizationHelper.LanguageId
                };

                var responsePreData = Execute<CreditCardApplicationGetDetailRequest, GenericResponse<NewCardApplicationPreDataContract>>(requestPreData);
                if (!responsePreData.Success || responsePreData.Value == null)
                {
                    result.AddMessage(Web.BusinessHelper.GetMessage("cardAppNoCardForApplication"), MessageType.Error, responsePreData.Results);
                    return result;
                }

                var eligableCard = responsePreData.Value.EligibleCardDataList?.FirstOrDefault(x => x.IsDebitCard);
                if (eligableCard == null)
                {
                    result.AddMessage(Web.BusinessHelper.GetMessage("cardAppNoCardForApplication"), MessageType.Error, responsePreData.Results);
                    return result;
                }
                WebContext.TransactionDataDictionary[SessionKeys.EligableCard] = eligableCard;

                preData = responsePreData.Value;
                WebContext.TransactionDataDictionary[SessionKeys.CreditCardApplicationPreData] = preData;
            }

            result.Model = preData;

            return result;



        }


        private void LoadAccountsForPreCheck()
        {
            WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSARAccount] = false;
            WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSelectedAccount] = false;
            var SelectedRegistration = (BOA.Types.Kernel.PaymentSystems.Religious.RegistrationDefinitionContract)(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration]);
            short fecValue = SelectedRegistration.Code == (byte)ReligiousCommon.RegistrationType.CONTRIBUTAION ? FecConstants.USD : SelectedRegistration.FEC;
            if (SelectedRegistration != null)
            {
                var accountComponentParameters = new BOA.Types.InternetBanking.AccountComponentParameters()
                {
                    ShowOnlyOpenAccounts = true,
                    ShowSharedAccounts = true,
                    ShowSharedAccountsWithMultiSignature = false,
                    DontShowPreciousMetals = true,
                    DontShowUnPreciousMetals = true,
                    FECList = new List<short>() { fecValue },
                    DontShowFinancialBlockedAccounts = true,
                    ShowOnlyAccountsHasAvailableBalance = false,
                    DontShowInvestmentAccounts = false
                };

                if (ReligiousHelper.IsRefund())
                {
                    accountComponentParameters.FECList = new List<short>() { (short)BOA.Types.Kernel.General.FECEnum.SAR };

                }

                var accountsResponse = this.LoadAccountComponentData(HtmlIds.SourceAccountComponentIndex, accountComponentParameters);
                if (accountsResponse != null && accountsResponse.Success && (accountsResponse.Value?.Any(x => x.FEC == (short)BOA.Types.Kernel.General.FECEnum.SAR) ?? false))
                {
                    WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSARAccount] = true;
                }
                if (accountsResponse.Success && accountsResponse != null & accountsResponse.Value.Count > 0)
                {
                    WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSelectedAccount] = true;
                }
            }
        }

        private void LoadAccountsForPreCheckAllAccount()
        {
            WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSelectedAccount] = false;
            var queryResult = WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo] != null ? (BOA.Types.Kernel.PaymentSystems.Religious.PaymentContract)(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.DeptInfo]) : null;

            var accountComponentParameters = new BOA.Types.InternetBanking.AccountComponentParameters()
            {
                ShowOnlyOpenAccounts = true,
                ShowSharedAccounts = true,
                ShowSharedAccountsWithMultiSignature = false,
                DontShowPreciousMetals = true,
                DontShowUnPreciousMetals = true,
                FECList = new List<short>() { queryResult.FEC.Value },
                DontShowFinancialBlockedAccounts = true,
                ShowOnlyAccountsHasAvailableBalance = false,
                DontShowInvestmentAccounts = false
            };


            var accountsResponse = this.LoadAccountComponentData(HtmlIds.SourceAccountComponentIndex, accountComponentParameters);
            if (accountsResponse.Success && accountsResponse != null & accountsResponse.Value.Count > 0)
            {
                WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistSelectedAccount] = true;
            }
        }

        private void LoadCreditCardsForPreCheck()
        {
            WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistCreditCard] = false;
            var parameters = new BOA.Types.InternetBanking.CreditCardListComponentParameters()
            {
                IsJustMainCard = true,
                ShowOnlyActiveCards = true,
                DontShowBusinessPlusMainCard = true
            };

            //Kart donusum projesi icin
            //var response = this.LoadCreditCardListComponentData(BOA.Web.InternetBanking.Religious.Types.HtmlIds.SourceCardComponentIndex, parameters);
            //if (response.Success && (response.Value?.Any() ?? false))
            //{
            //    WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistCreditCard] = true;
            //}

            bool? hasAnyRecord = null;
            var response = this.LoadCreditCardListComponentDataHasAnyRecord(BOA.Web.InternetBanking.Religious.Types.HtmlIds.SourceCardComponentIndex, parameters, ref hasAnyRecord);
            if (response.Success && (hasAnyRecord ?? false))
            {
                WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.IsExistCreditCard] = true;
            }
        }

        private void LoadPaymentComponentsData()
        {
            LoadAccountsForPreCheck();
            var SelectedRegistration = (BOA.Types.Kernel.PaymentSystems.Religious.RegistrationDefinitionContract)(WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.SelectedRegistration]);
            bool isSelectedContribution = SelectedRegistration.Code == (byte)BOA.Types.Kernel.PaymentSystems.Religious.ReligiousCommon.RegistrationType.CONTRIBUTAION;
            if (!isSelectedContribution)
            {
                LoadAccountsForPreCheckAllAccount();

                if (!ReligiousHelper.IsRefund() && ViewBag.IsCreditCardVisible)
                {
                    LoadCreditCardsForPreCheck();
                }
            }
        }

        private bool IsAuthorizedToOpenNewAccount()
        {
            var resourceList = WebResourceNodeHelper.GetUserResource() as List<WebResourceNode>;
            return resourceList?.Any(p => p.ResourceCode == ResourceCodeConstants.AccountsOpenAccountNew) ?? false;
        }

        private WebOpenAccountCurrentRequest CreateOpenAccountRequet(AccountContract accountContract, out int newAccountNumber, short Fec)
        {
            var accountNumber = accountContract?.AccountNumber ?? WebContext.UserContract.CustomerId;
            var branchId = accountContract?.BranchId ?? WebContext.UserContract.MainBranchId;

            if (branchId == 0)
            {
                var customerInfo = WebContext.TransactionDataDictionary[BOA.Web.InternetBanking.Religious.Types.SessionKeys.CustomerInfo] as CustomerInfoContract;
                branchId = customerInfo?.Branchid ?? 0;
            }
            newAccountNumber = accountNumber;

            var request = new WebOpenAccountCurrentRequest
            {
                AccountNumber = accountNumber,
                MainAccountNumber = accountNumber,
                AccountAlias = "",
                BranchId = branchId,
                FEC = Fec,
                MethodName = "OpenAccountCurrent"
            };

            return request;

        }
    }
}
