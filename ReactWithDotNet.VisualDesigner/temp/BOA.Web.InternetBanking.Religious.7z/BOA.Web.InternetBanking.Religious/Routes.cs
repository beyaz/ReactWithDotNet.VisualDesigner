﻿using System.Web.Mvc;

namespace BOA.Web.InternetBanking.Religious
{
    /// <summary>
    /// Routes Class Definition
    /// Auto Generated Documentation
    /// BOA class standard is described as below:
    /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
    /// TODO: More detail
    /// </summary>
    public class Routes : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Religious";
            }
        }

        /// <summary>
        /// RegisterArea Method Declaration
        /// Auto Generated Documentation
        /// BOA method standard is described as below:
        /// Naming convention must be in Pascal-Case, naming standard must be in English and clear.
        /// TODO: More detail
        /// </summary>
        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute("Religious", "Religious/{action}/{id}", new {
                controller = "Religious",
                action = "Index",
                id = UrlParameter.Optional
            }, new[] {
                "BOA.Web.InternetBanking.Religious.Controllers"
            });
        }
    }
}
